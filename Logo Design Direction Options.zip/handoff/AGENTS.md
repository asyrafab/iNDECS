# AGENTS.md — iNDECS

Binding rules for any coding agent (Claude Code, Codex, Antigravity) working in this
repository. Read this file and `docs/DESIGN-DIRECTION.md` before writing UI.

## The system

iNDECS is a Laravel application for MBSP development-control applications. It is
one shared core with four departmental applications:

| Application | Department | Application types |
|---|---|---|
| iNDECS Perancang | Jabatan Perancang Bandar | PKM |
| iNDECS Bangunan | Jabatan Bangunan | PB |
| iNDECS Kejuruteraan | Jabatan Kejuruteraan | PKT, PKP |
| iNDECS Landskap | Jabatan Landskap | PL |

Never name a module after a plan code alone: "PB" is ambiguous (Perancang Bandar
vs Pelan Bangunan). Route prefixes, table prefixes and reference formats are in
`docs/DESIGN-DIRECTION.md` — follow them exactly, do not invent new ones.

## Visual direction — Modernist

Flat, architectural, flush left. Archivo throughout. Zero corner radius. Strong
2px rules between sections. Ink on a light ground with a single red accent.

**Every value comes from `public/css/tokens.css`.**

- Never hard-code a hex, a font family, or a spacing/radius number the tokens carry. Use `var(--color-*)`, `var(--font-*)`, `var(--space-*)`, `var(--radius-*)`, `var(--shadow-*)`.
- Colour: `--color-bg` ground, `--color-text` ink, `--color-accent` (#ec3013) as the ONE accent. Use ramp steps (`--color-neutral-*`, `--color-accent-*`) rather than ad-hoc `color-mix()`. For accent-coloured body text use `--color-accent-700` — the base accent is only tuned to 3:1.
- Type: `--font-heading` (Archivo 800) for headings, `--font-body` for copy. Interface text never below 12px; table and form labels 11px uppercase at most.
- Structure: rules, not shadows. `2px solid var(--color-divider)` between major sections, `1px solid var(--color-rule-soft)` inside a section.
- Interaction: every interactive element gets a hover tint and a pressed state one ramp step past its base. Keyboard focus is `outline: 2px solid var(--color-accent); outline-offset: 2px` — never the browser default.
- Icons: Lucide (https://lucide.dev) only. Replace the glyph characters still used in the Blade views with Lucide SVGs as you touch each view.
- Status colour is MONO: outline = in motion, ink fill = settled, accent fill = needs attention. Do not introduce green/amber/blue status hues.

## Do not

- Do not round a corner. `--radius-md` is 0 on purpose.
- Do not centre button labels, headings or body copy. Everything is flush left.
- Do not add gradients, glows, blur, or decorative circles.
- Do not add a second accent colour, a colour-coded status palette, or emoji.
- Do not soften the 2px rules into hairlines, or replace them with whitespace.
- Do not introduce Tailwind utility styling into the Blade views alongside `indecs.css`; this app styles with the class layer in `public/css/indecs.css`.
- Do not tint or colourise photographs — greyscale only.

## Themes

Light and dark modes plus four accent choices are token-only: `data-theme` and
`data-accent` on `<html>`, switched by `public/js/theme.js` and stored in
localStorage. See `docs/DESIGN-DIRECTION.md` section 7.

- No component rule may branch on theme. If a value must differ per theme, add a TOKEN in `tokens.css` — never a `[data-theme="dark"] .some-component` override.
- Do not write `#fff` on an accent fill; use `var(--color-on-accent)`.
- The accent ramp is derived from `--accent-base` when an accent is chosen, so hovers and pressed states follow automatically. Do not hand-pick per-accent values.
- Four curated accents only (merah, hijau, biru, ambar). No free colour picker — an arbitrary hue breaks contrast and the mono discipline.

## Assets

- `public/img/indecs-mark.svg` — the mark (three offset squares, the leading one red)
- `public/img/indecs-mark-reversed.svg` — for dark grounds
- `public/img/indecs-lockup.svg` — mark + wordmark + BM name
- `public/img/mbsp.png` — the MBSP crest. Crest always LEADS, then a 2px rule, then iNDECS. Use on login, letterhead, printed approvals — not in the app header.

The mark's three squares double as the relationship indicator: one square =
standalone application, two = linked pair, three = development case.

## Working rules

- Bahasa Melayu is the interface language (`lang/ms`). Application type codes (PKM, PB, PKT, PKP, PL) stay as-is.
- Reuse the existing class names in `public/css/indecs.css` before inventing new ones. If you need a new component, add it to that file in the same idiom and document it here.
- Keep the audit and history model intact: never overwrite a stage or status without writing a history row.
