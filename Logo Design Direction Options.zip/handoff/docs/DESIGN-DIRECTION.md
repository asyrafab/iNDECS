# iNDECS — Design direction

Companion to AGENTS.md. This file is the specification a coding agent follows for
naming, structure, components and screens.

## 1. Naming (System A)

| Application | Full name | Menu | Route prefix | Table prefix | Reference format |
|---|---|---|---|---|---|
| Perancang | iNDECS Perancang | Perancang | `/perancang` | `APP_PKM_` | `PKM/2026/00125` |
| Bangunan | iNDECS Bangunan | Bangunan | `/bangunan` | `APP_PB_` | `PB/2026/00310` |
| Kejuruteraan | iNDECS Kejuruteraan | Kejuruteraan | `/kejuruteraan` | `APP_PKT_`, `APP_PKP_` | `PKT/2026/00054` |
| Landskap | iNDECS Landskap | Landskap | `/landskap` | `APP_PL_` | `PL/2026/00021` |

Short codes for menus and compact UI only, never in letters or reports: RANC,
BINA, KEJU, LAND.

Platform name is always `iNDECS` (lowercase i, uppercase NDECS). English name:
Intergrated Development Control System. Bahasa Melayu: Sistem Bersepada Kawalan
Pembangunan. Tagline (login and print only): Satu Platform, Pelbagai Permohonan
Pembangunan.

## 2. Screen inventory

Every departmental application uses the same workspace shell with the same tab
order. Only `Borang Jabatan` changes per department.

```
Ringkasan · Butiran · Pemohon & Perunding · Tapak & Lot · Peta ·
Borang Jabatan · Dokumen · Fi & Bayaran · Pergerakan Fail ·
Ulasan Teknikal · Tugasan · Mesyuarat · Keputusan · Kelulusan ·
Permohonan Berkaitan · Garis Masa · Sejarah Audit
```

Department form fields:

- **Perancang (PKM)** — kategori dan jenis kebenaran merancang, guna tanah sedia ada dan dicadangkan, komponen pembangunan, kepadatan, nisbah plot, bilangan unit, tingkat, ketinggian, syarat perancangan, tempoh sah kelulusan.
- **Bangunan (PB)** — kategori dan kegunaan bangunan, bilangan blok, tingkat, jumlah luas lantai dan luas lantai mengikut kegunaan, ketinggian, anjakan, tempat letak kenderaan, kebolehcapaian, nombor pelan diluluskan, syarat teknikal.
- **Kejuruteraan (PKT/PKP)** — aras sedia ada dan platform, korekan dan timbunan, cerun, struktur penahan, kawalan hakisan dan kelodak; kawasan tadahan, kadar alir reka bentuk, dimensi dan rizab parit, takungan, titik lepasan.
- **Landskap (PL)** — kategori landskap, kawasan lapang, softscape dan hardscape, pokok sedia ada dan dikekalkan, pokok dicadangkan dan spesies, tanaman penampan, kemudahan rekreasi, syarat tanaman gantian.

## 3. Workflow stages

- **Perancang** — Pendaftaran, Semakan kelengkapan, Taksiran fi, Pengesahan bayaran, Edaran teknikal, Penilaian perancangan, Mesyuarat jawatankuasa, Keputusan, Kelulusan, Tutup.
- **Bangunan** — Pendaftaran, Pengesahan dokumen dan pelan, Taksiran fi, Penilaian teknikal bangunan, Pindaan, Pengesahan pindaan, Kelulusan, Pengesahan pelan, Tutup.
- **Kejuruteraan** — Pendaftaran, Semakan kelengkapan, Penilaian selari (Kejuruteraan + Perancang Bandar), Pindaan, Syor bersepadu, Kelulusan, Tutup.
- **Landskap** — Pendaftaran, Ulasan teknikal landskap, Semakan pelan, Pindaan, Kelulusan, Pemantauan tempoh penyelenggaraan, Tutup.

Pelan Kerja Tanah is ONE application record with TWO department process rows
running in parallel. Neither department overwrites the other's assessment; the
consolidated recommendation and single approval come from Kejuruteraan.

## 4. Component states

Every component below exists in `public/css/indecs.css`. Use these; do not build
parallel components.

| Component | Class | States to honour |
|---|---|---|
| Button | `.button` + `-primary`, `-secondary`, `-ghost`, `-danger`, `-small`, `-large`, `.disabled` | hover tint, pressed one ramp step deeper, 2px accent focus ring, 45% opacity disabled |
| Input / select / textarea | bare elements | hover border, focus ring, placeholder in `--color-neutral-500`, disabled 45% |
| Table | `.data-table` | 2px header rule, 1px row rules, neutral-100 row hover, tabular numerals |
| Status | `.status-badge` + `.status-*` | outline = in motion, ink fill = settled, accent fill = attention |
| Card | `.content-card`, `.form-card`, `.detail-card`, `.side-card` | 2px border, no shadow, no radius |
| Nav | `.sidebar`, `.nav-link`, `.nav-link.active` | active = 4px accent left edge, never a filled pill |
| Alert | `.alert`, `-success`, `-error` | 4px left edge; error uses the accent |
| Metrics | `.metric-grid`, `.metric-card` | ink figures; at most one card carries the accent |
| Timeline | `.timeline` | current step accent, past steps neutral |

## 5. Delivery sequence

Teras bersama (core, GIS, documents) six months. The four departmental
applications then run concurrently with separate teams: Perancang 6 months,
Bangunan 6, Kejuruteraan 7, Landskap 5. Full launch at month 13.

## 6. Print and documents

Approval letters, endorsements and reports carry the MBSP crest leading, a 2px
rule, then iNDECS. Photographs print greyscale. Nothing rounded, nothing centred.

## 7. Themes and user preference

Two axes, both token-only:

| Attribute on `<html>` | Values | Default |
|---|---|---|
| `data-theme` | `light`, `dark`, absent = follow OS | absent |
| `data-accent` | `merah`, `hijau`, `biru`, `ambar` | `merah` |

`public/js/theme.js` reads and writes both, persists to localStorage, and keeps
the control's `aria-pressed` state in sync. Load it in `<head>` before the page
renders so there is no flash of the wrong theme.

The control markup is `resources/views/partials/theme-control.blade.php` — a
segmented Terang / Gelap / Sistem group plus four accent swatches, placed in the
topbar before `.user-chip`.

**Rules**

- Dark mode reverses the neutral ramp (100 stays the subtle fill step, 900 the strong ink step) so component CSS never branches on theme.
- The accent ramp is derived from `--accent-base` with `color-mix()`, and derives the other way on the dark ground (light steps carry text, deep steps carry tints).
- Accent fills use `var(--color-on-accent)` for their text, never a literal white.
- Four curated accents, no free picker. Adding a fifth means adding a `:root[data-accent="…"]` line in `tokens.css` and a swatch in the partial — nothing else.

**To persist per user instead of per browser:** store `theme_mode` and
`theme_accent` on the users table, render them as the two attributes on `<html>`
in `layouts/app.blade.php`, and POST the change from `theme.js`'s setters.
