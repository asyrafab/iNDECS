# iNDECS handoff package

Copy these into the repository root at `C:\\Users\\Asyra\\Documents\\iNDECS`,
keeping the folder structure:

```
AGENTS.md                      -> repo root (new)
CLAUDE.md                      -> repo root (new)
docs/DESIGN-DIRECTION.md       -> docs/ (new)
public/css/tokens.css          -> public/css/ (new)
public/css/indecs.css          -> public/css/ (REPLACES the existing file)
public/img/indecs-mark.svg     -> public/img/ (new folder)
public/img/indecs-mark-reversed.svg
public/img/indecs-lockup.svg
public/img/mbsp.png
public/js/theme.js             -> public/js/ (new)
resources/views/partials/theme-control.blade.php  -> resources/views/partials/ (new)
```

## Theming

Light/dark/system plus four accent choices. Two edits to
`resources/views/layouts/app.blade.php`:

1. In `<head>`, before the stylesheet: `<script src="{{ asset('js/theme.js') }}"></script>`
2. Inside `.topbar`, before `.user-chip`: `@include('partials.theme-control')`

Everything else is token-driven — see section 7 of `docs/DESIGN-DIRECTION.md`.

## About the CSS replacement

`public/css/indecs.css` is a full restyle of the first slice in the Modernist
direction. **Every class name is unchanged**, so no Blade view needs editing —
the layout, dashboard, PKM index/create/show and login views all keep working.
It `@import`s `tokens.css` (which loads Archivo from Google Fonts), so the
single `<link>` already in `layouts/app.blade.php` is enough.

Keep a copy of the old file if you want to compare.

## Two follow-ups worth doing

1. The Blade views still use glyph characters (☰ ⌂ ▤ ＋ ✓ ↪) as icons. Swap them for Lucide SVGs as you touch each view.
2. `resources/css/app.css` still declares Instrument Sans for the Tailwind pipeline. If Vite/Tailwind is going to be used at all, point its `@theme` font at Archivo so the two paths agree.
